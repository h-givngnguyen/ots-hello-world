# OTS-Plugin-Template

***

Use this repo as a base for writing plugins for OpenTAKServer. For a working plugin example, see the [AISStream Plugin](https://github.com/brian7704/OTS-AISStream-Plugin).
